#include <opencv2/opencv.hpp>
#include <iostream>
#include "LKTracker.h"

using namespace std;
using namespace cv;

Rect box;
bool drawing_box = false;
bool gotBB = false;



//bounding box mouse callback
void mouseHandler(int event, int x, int y, int flags, void *param) {
	switch (event) {
	case CV_EVENT_MOUSEMOVE:
		if (drawing_box) {
			box.width = x - box.x;
			box.height = y - box.y;
		}
		break;
	case CV_EVENT_LBUTTONDOWN:
		drawing_box = true;
		box = Rect(x, y, 0, 0);
		break;
	case CV_EVENT_LBUTTONUP:
		drawing_box = false;
		if (box.width < 0) {
			box.x += box.width;
			box.width *= -1;
		}
		if (box.height < 0) {
			box.y += box.height;
			box.height *= -1;
		}
		gotBB = true;
		break;
	}
}






float median(vector<float> v)
{
	int n = floor(v.size() / 2);
	nth_element(v.begin(), v.begin() + n, v.end());
	return v[n];
}
void bbPoints(vector<cv::Point2f>& points, const Rect& bb) {
	int max_pts = 10;
	int margin_h = 0;
	int margin_v = 0;
	int stepx = ceil((bb.width - 2 * margin_h) / max_pts);
	int stepy = ceil((bb.height - 2 * margin_v) / max_pts);
	for (int y = bb.y + margin_v; y<bb.y + bb.height - margin_v; y += stepy) {
		for (int x = bb.x + margin_h; x<bb.x + bb.width - margin_h; x += stepx) {
			points.push_back(Point2f(x, y));
		}
	}
}
void bbPredict(const vector<cv::Point2f>& points1, const vector<cv::Point2f>& points2,
	const Rect& bb1, Rect& bb2) {
	int npoints = (int)points1.size();
	vector<float> xoff(npoints);
	vector<float> yoff(npoints);
	printf("tracked points : %d\n", npoints);
	for (int i = 0; i<npoints; i++) {
		xoff[i] = points2[i].x - points1[i].x;
		yoff[i] = points2[i].y - points1[i].y;
	}
	float dx = median(xoff);
	float dy = median(yoff);
	float s;
	if (npoints>1) {
		vector<float> d;
		d.reserve(npoints*(npoints - 1) / 2);
		for (int i = 0; i<npoints; i++) {
			for (int j = i + 1; j<npoints; j++) {
				d.push_back(norm(points2[i] - points2[j]) / norm(points1[i] - points1[j]));
			}
		}
		s = median(d);
	}
	else {
		s = 1.0;
	}
	float s1 = 0.5*(s - 1)*bb1.width;
	float s2 = 0.5*(s - 1)*bb1.height;
	printf("s= %f s1= %f s2= %f \n", s, s1, s2);
	bb2.x = round(bb1.x + dx - s1);
	bb2.y = round(bb1.y + dy - s2);
	bb2.width = round(bb1.width*s);
	bb2.height = round(bb1.height*s);
	printf("predicted bb: %d %d %d %d\n", bb2.x, bb2.y, bb2.br().x, bb2.br().y);
}

int main()
{
	VideoCapture capture;
	capture.open(0);
	namedWindow("frame", 1);
	setMouseCallback("frame", mouseHandler, NULL);
	Mat frame,last_gray;
	while (!gotBB)
	{
		capture >> frame;
		cvtColor(frame, last_gray, CV_RGB2GRAY);
		rectangle(frame, box, cvScalarAll(255), 1);
		imshow("frame", frame);
		if (waitKey(30) == 27)
		{
			break;
		}
	}
	Mat current_gray;
	vector<Point2f> pts1;
	vector<Point2f> pts2;
	Rect last_box = box;
	Rect tbb;
	LKTracker tracker;
	while (capture.read(frame))
	{
		cvtColor(frame, current_gray, CV_RGB2GRAY);
		bbPoints(pts1, last_box);
		vector<Point2f> points = pts1;
		tracker.trackf2f(last_gray, current_gray, points, pts2);
		bbPredict(points, pts2, last_box, tbb);
		rectangle(frame, tbb, cvScalarAll(255), 1);
		imshow("frame", frame);
		swap(last_gray, current_gray);
		last_box = tbb;
		pts1.clear();
		pts2.clear();
		if (waitKey(30) == 27)
		{
			break;
		}
	}

}
